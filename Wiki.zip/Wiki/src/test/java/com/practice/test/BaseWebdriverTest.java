package com.practice.test;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;
/**
 * Base test that will instantiate webdrive before the test run
 * @author Sunitha Pitla
 * @created Mar 2021
 */

public class BaseWebdriverTest {

	private static WebDriver driver;

	@BeforeSuite
	public void setWebdriver() {
		System.setProperty("webdriver.chrome.driver", "/users/spitla/eclipse-workspace/spitla_webdriver/chromedriver");
	}	
	
	@BeforeTest
	public void openWebdriver() {
		driver = new ChromeDriver();
	}

	@AfterTest
	public void logout() {
		driver.close();
		driver.quit();
	}
	
	public WebDriver getDriver() {
        return driver;
    }
}


