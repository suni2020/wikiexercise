package com.practice.test;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertTrue;

import java.util.Collections;
import java.util.List;

import org.testng.annotations.Test;

import com.test.pageobject.WikiPage;

/**
 * Test Wiki.
 * @author Sunitha Pitla
 * @created Mar 2021
 */

public class WikiMainTest extends BaseWebdriverTest {

	private static final String metisPageUrl = "Metis_(mythology)";
	private static final String metisPageName = "Metis (mythology)";
	
	/**
	 * test to verify that contents box items match with headings in the page
	 */
	@Test
	public void testContentsBoxAndHeadingMatch() throws Exception {
		WikiPage metisPage = new WikiPage(getDriver(), metisPageUrl, metisPageName);
		List<String> contents = metisPage.getContentBoxItems();
		List<String> headings = metisPage.getHeadings();
		Collections.sort(contents);
		Collections.sort(headings);//sort both list before comparing
		
		//verify both the lists match
		assertEquals(contents, headings, "the elements in content box did not match with headings");
	}
	
	/**
	 * test to verify that contents box items have functioning hyperlinks
	 */
	@Test
	public void testContentsItemsWithHyperlinks() throws Exception {
		WikiPage metisPage = new WikiPage(getDriver(), metisPageUrl, metisPageName);
		//get the list of contents
		List<String> contents = metisPage.getContentBoxItems();
		
		//verify each content item has an hyperlink and a corresponding heading
		//example: verify there is element <a href="#Family"  ...> and a corresponding #Family heading		
		for(String s : contents) {
			assertTrue(metisPage.isContentItemHyperLinkPresent(s), "the content item " + s +" has no href link");
			assertTrue(metisPage.isheadingsAnchorPresent(s), "the heading anchor for: " + s +" is not present");
		}		
	}
	
	/**
	 * test to verify the popup text
	 */
	@Test
	public void testVerifyPopupText() throws Exception {
		WikiPage metisPage = new WikiPage(getDriver(), metisPageUrl, metisPageName);
		
		//hover Nike and get the text from pop up
		metisPage.mouseOverSideBarLink("Nike");
		String text = metisPage.getTextFromHoverPopup();
		final String expPopupText = "In ancient Greek religion, Nike was a goddess who personified victory. Her Roman equivalent was Victoria.";
		
		//verify the text matches
		assertEquals(text, expPopupText, "pop up text did not match expected");
		
	}
	
	/**
	 * test to verify the Navigation from personified link: Nike
	 */
	@Test
	public void testNavigationPersonifiedConcepts() throws Exception {
		WikiPage metisPage = new WikiPage(getDriver(), metisPageUrl, metisPageName);
		
		//click on the side bar link(Nike) and verify Nike page loads.
		metisPage.clickSidebarLink("Nike");
		metisPage.waitForWikiPageToLoad("Nike (mythology)");
	}
}
