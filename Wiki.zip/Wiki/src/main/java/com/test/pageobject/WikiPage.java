package com.test.pageobject;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
/**
 * Page object for the wiki page
 * 
 * @author Sunitha Pitla
 * @created Mar 2021
 */
public class WikiPage extends BasePage{

	private WebDriver driver;
	private Actions action;
	
	
	private static final By ContentsBoxItem = By.cssSelector("#toc>ul>li>a>span.toctext");
	private static final String ContentsBoxHyperlink = "#toc>ul>li>a[href='#%s']";
	private static final By headings = By.cssSelector("span.mw-headline");
	private static final String headingsAnchor ="span.mw-headline#%s";
	private static final String sideBarLink = ".sidebar li>a[title ^='%s']";
	private static final String firstHeading = "//h1[contains(text(), '%s')]";
	private static final By popup = By.cssSelector(".mwe-popups p");

	public WikiPage(WebDriver driver, String pageUrl, String pageName) throws Exception {
		super(driver);
		action = new Actions(driver);
		getPage(pageUrl, pageName);
	}

	private BasePage getPage(String pageUrl, String pageName) throws Exception {			
		String url = BaseUrl+"/"+pageUrl;
	    driver.get(url);
	    waitForElementToBeVisible(By.xpath(String.format(firstHeading, pageName)));
		return this;
	}
	
	public List<String> getContentBoxItems() throws Exception {
		return getElementStrings(ContentsBoxItem);
	}
	
	public List<String> getHeadings() throws Exception {
		return getElementStrings(headings);
	}
	
	private List<String> getElementStrings(By item) throws Exception {
		List<WebElement> elements = driver.findElements(item);
		List<String> elementStrings = new ArrayList<String>(elements.size());
		for(WebElement e : elements) {
			elementStrings.add(e.getText());
		}
		return elementStrings;
	}
	
	public Boolean isContentItemHyperLinkPresent(String item) {
		return driver.findElement(By.cssSelector(String.format(ContentsBoxHyperlink,item))).isDisplayed();
	}
	
	public Boolean isheadingsAnchorPresent(String item) {
		return driver.findElement(By.cssSelector(String.format(headingsAnchor,item))).isDisplayed();
	}
	
	public void mouseOverSideBarLink(String item) {
		WebElement we = driver.findElement(By.cssSelector(String.format(sideBarLink,item)));
		action.moveToElement(we);
	}
	
	public String getTextFromHoverPopup() {
		waitForElementToBeVisible(popup);
		return driver.findElement(popup).getText();
	}
	
	public void clickSidebarLink(String item) {
		WebElement we = driver.findElement(By.cssSelector(String.format(sideBarLink,item)));
		action.click(we);
	}
	
	public WikiPage waitForWikiPageToLoad(String pageName) {
		waitForElementToBeVisible(By.xpath(String.format(firstHeading, pageName)));
		return this;
	}
		
}


