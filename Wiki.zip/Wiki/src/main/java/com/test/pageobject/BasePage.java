package com.test.pageobject;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.pagefactory.AjaxElementLocatorFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class BasePage {

	protected static final String BaseUrl = "https://en.wikipedia.org/wiki";
	
	private static final int TimeOut = 45;
    private static final int Poll = 100;

    protected WebDriver driver;
    private WebDriverWait wait;

    @SuppressWarnings("deprecation")
	public BasePage(WebDriver driver) {
        this.driver = driver;
        wait = new WebDriverWait(driver, TimeOut, Poll);
        PageFactory.initElements(new AjaxElementLocatorFactory(driver, TimeOut), this);
    }

    protected void waitForElementToBeVisible(By locator) {
        wait.until(ExpectedConditions.visibilityOfElementLocated(locator));
    }
}
